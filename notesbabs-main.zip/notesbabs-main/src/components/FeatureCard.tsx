import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { LucideIcon } from "lucide-react";
import { cn } from "@/lib/utils";

interface FeatureCardProps {
  title: string;
  description: string;
  icon: LucideIcon;
  href: string;
  gradient: "primary" | "accent" | "success" | "warning";
  stats?: string;
  delay?: number;
}

const gradientClasses = {
  primary: "from-navy to-navy-light",
  accent: "from-saffron-dark to-saffron",
  success: "from-emerald-600 to-emerald-500",
  warning: "from-amber-600 to-amber-500",
};

export function FeatureCard({
  title,
  description,
  icon: Icon,
  href,
  gradient,
  stats,
  delay = 0,
}: FeatureCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: delay * 0.1, duration: 0.5 }}
    >
      <Link to={href} className="block group">
        <div className="relative overflow-hidden rounded-2xl bg-card border shadow-md hover:shadow-xl transition-all duration-300 hover:-translate-y-1">
          {/* Gradient header */}
          <div
            className={cn(
              "h-32 bg-gradient-to-br flex items-center justify-center relative overflow-hidden",
              gradientClasses[gradient]
            )}
          >
            <div className="absolute inset-0 bg-black/0 group-hover:bg-black/5 transition-colors" />
            <Icon className="h-12 w-12 text-white/90 group-hover:scale-110 transition-transform duration-300" />
            
            {/* Decorative circles */}
            <div className="absolute -top-8 -right-8 w-32 h-32 bg-white/10 rounded-full" />
            <div className="absolute -bottom-8 -left-8 w-24 h-24 bg-white/5 rounded-full" />
          </div>

          {/* Content */}
          <div className="p-5">
            <h3 className="font-display font-semibold text-lg mb-1 group-hover:text-accent transition-colors">
              {title}
            </h3>
            <p className="text-muted-foreground text-sm line-clamp-2">
              {description}
            </p>
            {stats && (
              <div className="mt-3 pt-3 border-t">
                <span className="text-xs font-medium text-accent">{stats}</span>
              </div>
            )}
          </div>
        </div>
      </Link>
    </motion.div>
  );
}
