import { Outlet } from "react-router-dom";
import { Navbar } from "@/components/Navbar";
import { usePushNotifications } from "@/hooks/use-push-notifications";

export function DashboardLayout() {
  usePushNotifications();

  return (
    <div className="min-h-screen bg-background safe-bottom">
      <Navbar />
      <main className="container mx-auto px-4 py-6 safe-x">
        <Outlet />
      </main>
    </div>
  );
}
