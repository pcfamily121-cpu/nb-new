import { motion } from "framer-motion";
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Newspaper, Download, Calendar, TrendingUp } from "lucide-react";

const months = [
  "All Months",
  "January 2026",
  "December 2025",
  "November 2025",
  "October 2025",
];

const currentAffairs = [
  {
    id: 1,
    title: "January 2026 - Complete Monthly Compilation",
    month: "January 2026",
    description: "Comprehensive coverage of all important national and international events",
    downloads: 450,
    isNew: true,
  },
  {
    id: 2,
    title: "December 2025 - Monthly Current Affairs",
    month: "December 2025",
    description: "Year-end summary with focus on government schemes and international summits",
    downloads: 1200,
    isNew: false,
  },
  {
    id: 3,
    title: "November 2025 - Monthly Compilation",
    month: "November 2025",
    description: "Focus on economic updates, science achievements, and policy changes",
    downloads: 980,
    isNew: false,
  },
  {
    id: 4,
    title: "October 2025 - Current Affairs PDF",
    month: "October 2025",
    description: "Festival season updates, budget analysis, and international relations",
    downloads: 1100,
    isNew: false,
  },
];

export default function CurrentAffairs() {
  const [selectedMonth, setSelectedMonth] = useState("All Months");

  const filteredAffairs = currentAffairs.filter((item) => {
    return selectedMonth === "All Months" || item.month === selectedMonth;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex flex-col md:flex-row md:items-center justify-between gap-4"
      >
        <div>
          <h1 className="text-3xl font-display font-bold flex items-center gap-3">
            <div className="p-2 rounded-xl bg-accent/10">
              <Newspaper className="h-7 w-7 text-accent" />
            </div>
            Current Affairs
          </h1>
          <p className="text-muted-foreground mt-1">
            Stay updated with daily, weekly & monthly compilations
          </p>
        </div>
      </motion.div>

      {/* Quick Stats */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.1 }}
        className="grid grid-cols-2 md:grid-cols-4 gap-4"
      >
        <Card className="border-0 shadow-md bg-gradient-to-br from-blue-500 to-blue-600 text-white">
          <CardContent className="p-4">
            <TrendingUp className="h-6 w-6 mb-2 opacity-80" />
            <p className="text-2xl font-bold">Daily</p>
            <p className="text-sm opacity-80">Updates Available</p>
          </CardContent>
        </Card>
        <Card className="border-0 shadow-md bg-gradient-to-br from-emerald-500 to-emerald-600 text-white">
          <CardContent className="p-4">
            <Calendar className="h-6 w-6 mb-2 opacity-80" />
            <p className="text-2xl font-bold">Weekly</p>
            <p className="text-sm opacity-80">Compilations</p>
          </CardContent>
        </Card>
        <Card className="border-0 shadow-md bg-gradient-to-br from-purple-500 to-purple-600 text-white">
          <CardContent className="p-4">
            <Newspaper className="h-6 w-6 mb-2 opacity-80" />
            <p className="text-2xl font-bold">Monthly</p>
            <p className="text-sm opacity-80">PDF Magazines</p>
          </CardContent>
        </Card>
        <Card className="border-0 shadow-md bg-gradient-to-br from-orange-500 to-orange-600 text-white">
          <CardContent className="p-4">
            <Download className="h-6 w-6 mb-2 opacity-80" />
            <p className="text-2xl font-bold">5000+</p>
            <p className="text-sm opacity-80">Total Downloads</p>
          </CardContent>
        </Card>
      </motion.div>

      {/* Filter */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.2 }}
      >
        <Select value={selectedMonth} onValueChange={setSelectedMonth}>
          <SelectTrigger className="w-full sm:w-48">
            <Calendar className="h-4 w-4 mr-2" />
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {months.map((month) => (
              <SelectItem key={month} value={month}>
                {month}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </motion.div>

      {/* Current Affairs List */}
      <div className="space-y-4">
        {filteredAffairs.map((item, index) => (
          <motion.div
            key={item.id}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: index * 0.1 }}
          >
            <Card className="border-0 shadow-md hover:shadow-lg transition-all duration-300">
              <CardContent className="p-6">
                <div className="flex flex-col md:flex-row md:items-center gap-4">
                  <div className="flex-shrink-0">
                    <div className="h-16 w-16 rounded-xl bg-gradient-to-br from-accent to-saffron-light flex items-center justify-center">
                      <Newspaper className="h-8 w-8 text-white" />
                    </div>
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <h3 className="text-lg font-semibold">{item.title}</h3>
                      {item.isNew && (
                        <Badge className="bg-emerald-500 text-white">New</Badge>
                      )}
                    </div>
                    <p className="text-muted-foreground text-sm mb-2">
                      {item.description}
                    </p>
                    <div className="flex items-center gap-4 text-sm text-muted-foreground">
                      <span className="flex items-center gap-1">
                        <Calendar className="h-4 w-4" />
                        {item.month}
                      </span>
                      <span className="flex items-center gap-1">
                        <Download className="h-4 w-4" />
                        {item.downloads.toLocaleString()} downloads
                      </span>
                    </div>
                  </div>
                  <div>
                    <Button className="gap-2">
                      <Download className="h-4 w-4" />
                      Download PDF
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
