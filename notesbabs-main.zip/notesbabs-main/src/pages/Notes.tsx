import { motion } from "framer-motion";
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { FileText, Download, Search, BookOpen, Filter } from "lucide-react";

const subjects = [
  "All Subjects",
  "History",
  "Geography",
  "Polity",
  "Economy",
  "Environment",
  "Science & Tech",
  "Ethics",
  "Essay",
];

const sampleNotes = [
  {
    id: 1,
    title: "Ancient India - Complete Notes",
    subject: "History",
    category: "NCERT Summary",
    downloads: 1250,
    isPremium: false,
  },
  {
    id: 2,
    title: "Indian Geography - Physical Features",
    subject: "Geography",
    category: "Standard Notes",
    downloads: 980,
    isPremium: false,
  },
  {
    id: 3,
    title: "Constitution of India - Part I to IV",
    subject: "Polity",
    category: "Laxmikanth Summary",
    downloads: 2100,
    isPremium: true,
  },
  {
    id: 4,
    title: "Indian Economy - Basic Concepts",
    subject: "Economy",
    category: "Ramesh Singh",
    downloads: 1500,
    isPremium: false,
  },
  {
    id: 5,
    title: "Environment & Ecology - Shankar IAS",
    subject: "Environment",
    category: "Complete Notes",
    downloads: 890,
    isPremium: true,
  },
  {
    id: 6,
    title: "Science & Technology 2025",
    subject: "Science & Tech",
    category: "Current Topics",
    downloads: 670,
    isPremium: false,
  },
];

export default function Notes() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedSubject, setSelectedSubject] = useState("All Subjects");

  const filteredNotes = sampleNotes.filter((note) => {
    const matchesSearch = note.title.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesSubject = selectedSubject === "All Subjects" || note.subject === selectedSubject;
    return matchesSearch && matchesSubject;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex flex-col md:flex-row md:items-center justify-between gap-4"
      >
        <div>
          <h1 className="text-3xl font-display font-bold flex items-center gap-3">
            <div className="p-2 rounded-xl bg-accent/10">
              <FileText className="h-7 w-7 text-accent" />
            </div>
            Study Notes
          </h1>
          <p className="text-muted-foreground mt-1">
            High-quality PDF notes for all UPSC subjects
          </p>
        </div>
      </motion.div>

      {/* Filters */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.1 }}
        className="flex flex-col sm:flex-row gap-4"
      >
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search notes..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>
        <Select value={selectedSubject} onValueChange={setSelectedSubject}>
          <SelectTrigger className="w-full sm:w-48">
            <Filter className="h-4 w-4 mr-2" />
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {subjects.map((subject) => (
              <SelectItem key={subject} value={subject}>
                {subject}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </motion.div>

      {/* Notes Grid */}
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredNotes.map((note, index) => (
          <motion.div
            key={note.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
          >
            <Card className="border-0 shadow-md hover:shadow-lg transition-all duration-300 overflow-hidden group">
              <div className="h-24 bg-gradient-to-br from-navy to-navy-light flex items-center justify-center relative">
                <BookOpen className="h-10 w-10 text-white/80" />
                {note.isPremium && (
                  <Badge className="absolute top-2 right-2 bg-accent text-accent-foreground">
                    Premium
                  </Badge>
                )}
              </div>
              <CardHeader className="pb-2">
                <div className="flex items-start justify-between gap-2">
                  <CardTitle className="text-base line-clamp-2 group-hover:text-accent transition-colors">
                    {note.title}
                  </CardTitle>
                </div>
                <div className="flex gap-2">
                  <Badge variant="secondary" className="text-xs">
                    {note.subject}
                  </Badge>
                  <Badge variant="outline" className="text-xs">
                    {note.category}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground flex items-center gap-1">
                    <Download className="h-3 w-3" />
                    {note.downloads.toLocaleString()} downloads
                  </span>
                  <Button size="sm" className="gap-2">
                    <Download className="h-4 w-4" />
                    Download
                  </Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      {filteredNotes.length === 0 && (
        <div className="text-center py-12">
          <FileText className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
          <h3 className="text-lg font-medium mb-2">No notes found</h3>
          <p className="text-muted-foreground">Try adjusting your search or filter</p>
        </div>
      )}
    </div>
  );
}
