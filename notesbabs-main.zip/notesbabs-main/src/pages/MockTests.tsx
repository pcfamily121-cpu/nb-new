import { motion } from "framer-motion";
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Target,
  Clock,
  FileQuestion,
  Play,
  Trophy,
  BarChart3,
  BookOpen,
} from "lucide-react";

const prelimsTests = [
  {
    id: 1,
    title: "Prelims Mock Test - Set 1",
    subject: "General Studies",
    questions: 100,
    duration: 120,
    difficulty: "Medium",
    attempts: 245,
  },
  {
    id: 2,
    title: "History PYQ Practice",
    subject: "History",
    questions: 50,
    duration: 60,
    difficulty: "Hard",
    attempts: 189,
  },
  {
    id: 3,
    title: "Geography Full Length Test",
    subject: "Geography",
    questions: 75,
    duration: 90,
    difficulty: "Medium",
    attempts: 156,
  },
  {
    id: 4,
    title: "Polity & Governance",
    subject: "Polity",
    questions: 60,
    duration: 75,
    difficulty: "Easy",
    attempts: 312,
  },
];

const mainsTests = [
  {
    id: 1,
    title: "GS Paper 1 - Full Syllabus",
    subject: "General Studies 1",
    questions: 20,
    duration: 180,
    difficulty: "Hard",
    attempts: 89,
  },
  {
    id: 2,
    title: "Essay Writing Practice",
    subject: "Essay",
    questions: 2,
    duration: 180,
    difficulty: "Hard",
    attempts: 67,
  },
  {
    id: 3,
    title: "Ethics Case Studies",
    subject: "Ethics",
    questions: 15,
    duration: 120,
    difficulty: "Medium",
    attempts: 134,
  },
];

const getDifficultyColor = (difficulty: string) => {
  switch (difficulty) {
    case "Easy":
      return "bg-emerald-100 text-emerald-700";
    case "Medium":
      return "bg-yellow-100 text-yellow-700";
    case "Hard":
      return "bg-red-100 text-red-700";
    default:
      return "bg-gray-100 text-gray-700";
  }
};

export default function MockTests() {
  const [activeTab, setActiveTab] = useState("prelims");

  return (
    <div className="space-y-6">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex flex-col md:flex-row md:items-center justify-between gap-4"
      >
        <div>
          <h1 className="text-3xl font-display font-bold flex items-center gap-3">
            <div className="p-2 rounded-xl bg-accent/10">
              <Target className="h-7 w-7 text-accent" />
            </div>
            Mock Tests
          </h1>
          <p className="text-muted-foreground mt-1">
            PYQ-based mock tests for Prelims & Mains preparation
          </p>
        </div>
      </motion.div>

      {/* Quick Stats */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.1 }}
        className="grid grid-cols-2 md:grid-cols-4 gap-4"
      >
        <Card className="border-0 shadow-md">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="p-2 rounded-lg bg-blue-100">
              <FileQuestion className="h-5 w-5 text-blue-600" />
            </div>
            <div>
              <p className="text-xl font-bold">100+</p>
              <p className="text-xs text-muted-foreground">Total Tests</p>
            </div>
          </CardContent>
        </Card>
        <Card className="border-0 shadow-md">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="p-2 rounded-lg bg-emerald-100">
              <Trophy className="h-5 w-5 text-emerald-600" />
            </div>
            <div>
              <p className="text-xl font-bold">0</p>
              <p className="text-xs text-muted-foreground">Tests Completed</p>
            </div>
          </CardContent>
        </Card>
        <Card className="border-0 shadow-md">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="p-2 rounded-lg bg-purple-100">
              <BarChart3 className="h-5 w-5 text-purple-600" />
            </div>
            <div>
              <p className="text-xl font-bold">--</p>
              <p className="text-xs text-muted-foreground">Avg. Score</p>
            </div>
          </CardContent>
        </Card>
        <Card className="border-0 shadow-md">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="p-2 rounded-lg bg-orange-100">
              <Clock className="h-5 w-5 text-orange-600" />
            </div>
            <div>
              <p className="text-xl font-bold">0h</p>
              <p className="text-xs text-muted-foreground">Time Spent</p>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Tests Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-2 h-12">
          <TabsTrigger value="prelims" className="gap-2">
            <Target className="h-4 w-4" /> Prelims Tests
          </TabsTrigger>
          <TabsTrigger value="mains" className="gap-2">
            <BookOpen className="h-4 w-4" /> Mains Tests
          </TabsTrigger>
        </TabsList>

        <TabsContent value="prelims" className="space-y-4">
          {prelimsTests.map((test, index) => (
            <motion.div
              key={test.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <Card className="border-0 shadow-md hover:shadow-lg transition-all duration-300">
                <CardContent className="p-6">
                  <div className="flex flex-col md:flex-row md:items-center gap-4">
                    <div className="flex-shrink-0">
                      <div className="h-14 w-14 rounded-xl bg-gradient-to-br from-navy to-navy-light flex items-center justify-center">
                        <Target className="h-7 w-7 text-white" />
                      </div>
                    </div>
                    <div className="flex-1">
                      <h3 className="text-lg font-semibold">{test.title}</h3>
                      <div className="flex flex-wrap items-center gap-2 mt-2">
                        <Badge variant="secondary">{test.subject}</Badge>
                        <Badge className={getDifficultyColor(test.difficulty)}>
                          {test.difficulty}
                        </Badge>
                      </div>
                      <div className="flex items-center gap-4 mt-2 text-sm text-muted-foreground">
                        <span className="flex items-center gap-1">
                          <FileQuestion className="h-4 w-4" />
                          {test.questions} Questions
                        </span>
                        <span className="flex items-center gap-1">
                          <Clock className="h-4 w-4" />
                          {test.duration} mins
                        </span>
                        <span className="flex items-center gap-1">
                          <Trophy className="h-4 w-4" />
                          {test.attempts} attempts
                        </span>
                      </div>
                    </div>
                    <div>
                      <Button className="gap-2">
                        <Play className="h-4 w-4" />
                        Start Test
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </TabsContent>

        <TabsContent value="mains" className="space-y-4">
          {mainsTests.map((test, index) => (
            <motion.div
              key={test.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <Card className="border-0 shadow-md hover:shadow-lg transition-all duration-300">
                <CardContent className="p-6">
                  <div className="flex flex-col md:flex-row md:items-center gap-4">
                    <div className="flex-shrink-0">
                      <div className="h-14 w-14 rounded-xl bg-gradient-to-br from-accent to-saffron-light flex items-center justify-center">
                        <BookOpen className="h-7 w-7 text-white" />
                      </div>
                    </div>
                    <div className="flex-1">
                      <h3 className="text-lg font-semibold">{test.title}</h3>
                      <div className="flex flex-wrap items-center gap-2 mt-2">
                        <Badge variant="secondary">{test.subject}</Badge>
                        <Badge className={getDifficultyColor(test.difficulty)}>
                          {test.difficulty}
                        </Badge>
                      </div>
                      <div className="flex items-center gap-4 mt-2 text-sm text-muted-foreground">
                        <span className="flex items-center gap-1">
                          <FileQuestion className="h-4 w-4" />
                          {test.questions} Questions
                        </span>
                        <span className="flex items-center gap-1">
                          <Clock className="h-4 w-4" />
                          {test.duration} mins
                        </span>
                        <span className="flex items-center gap-1">
                          <Trophy className="h-4 w-4" />
                          {test.attempts} attempts
                        </span>
                      </div>
                    </div>
                    <div>
                      <Button className="gap-2">
                        <Play className="h-4 w-4" />
                        Start Test
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </TabsContent>
      </Tabs>
    </div>
  );
}
