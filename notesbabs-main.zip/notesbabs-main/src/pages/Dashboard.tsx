import { motion } from "framer-motion";
import { useAuth } from "@/contexts/AuthContext";
import { FeatureCard } from "@/components/FeatureCard";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import {
  FileText,
  Newspaper,
  Brain,
  Target,
  PenTool,
  TrendingUp,
  Award,
  Clock,
  BookOpen,
} from "lucide-react";

const features = [
  {
    title: "Study Notes",
    description: "High-quality PDF notes covering all UPSC subjects with expert insights",
    icon: FileText,
    href: "/notes",
    gradient: "primary" as const,
    stats: "500+ PDFs available",
  },
  {
    title: "Current Affairs",
    description: "Daily, weekly & monthly current affairs compilations for UPSC",
    icon: Newspaper,
    href: "/current-affairs",
    gradient: "accent" as const,
    stats: "Updated daily",
  },
  {
    title: "AI Evaluation",
    description: "Get your answers evaluated by AI with detailed feedback and scoring",
    icon: Brain,
    href: "/ai-evaluation",
    gradient: "success" as const,
    stats: "Instant feedback",
  },
  {
    title: "Mock Tests",
    description: "PYQ-based mock tests for Prelims with detailed analytics",
    icon: Target,
    href: "/mock-tests",
    gradient: "warning" as const,
    stats: "100+ tests",
  },
  {
    title: "Mains Abhyas",
    description: "Daily mains answer writing practice with AI topic analysis",
    icon: PenTool,
    href: "/mains-abhyas",
    gradient: "primary" as const,
    stats: "250+ questions",
  },
];

const stats = [
  { label: "Tests Taken", value: 0, icon: Target },
  { label: "Answers Evaluated", value: 0, icon: Brain },
  { label: "Notes Downloaded", value: 0, icon: FileText },
  { label: "Hours Studied", value: 0, icon: Clock },
];

export default function Dashboard() {
  const { user } = useAuth();
  const userName = user?.user_metadata?.full_name?.split(" ")[0] || "Aspirant";

  return (
    <div className="space-y-8">
      {/* Welcome Section */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative overflow-hidden rounded-3xl gradient-hero p-8 text-primary-foreground"
      >
        {/* Decorative elements */}
        <div className="absolute top-0 right-0 w-64 h-64 bg-accent/20 rounded-full blur-3xl" />
        <div className="absolute bottom-0 left-1/4 w-48 h-48 bg-accent/10 rounded-full blur-2xl" />
        
        <div className="relative z-10">
          <div className="flex items-center gap-3 mb-2">
            <div className="p-2 rounded-xl bg-accent/20">
              <BookOpen className="h-6 w-6" />
            </div>
            <span className="text-primary-foreground/70 text-sm font-medium">
              Welcome back!
            </span>
          </div>
          <h1 className="text-3xl md:text-4xl font-display font-bold mb-2">
            Hello, {userName}! 👋
          </h1>
          <p className="text-primary-foreground/80 max-w-2xl">
            Continue your UPSC preparation journey. Your dedication today shapes your success tomorrow.
          </p>
        </div>
      </motion.div>

      {/* Quick Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {stats.map((stat, index) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
          >
            <Card className="border-0 shadow-md hover:shadow-lg transition-shadow">
              <CardContent className="p-4 flex items-center gap-4">
                <div className="p-3 rounded-xl bg-accent/10">
                  <stat.icon className="h-5 w-5 text-accent" />
                </div>
                <div>
                  <p className="text-2xl font-bold">{stat.value}</p>
                  <p className="text-xs text-muted-foreground">{stat.label}</p>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      {/* Features Grid */}
      <div>
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-display font-bold">Explore Features</h2>
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, index) => (
            <FeatureCard key={feature.href} {...feature} delay={index} />
          ))}
        </div>
      </div>

      {/* Progress Section */}
      <div className="grid md:grid-cols-2 gap-6">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.3 }}
        >
          <Card className="border-0 shadow-md">
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center gap-2 text-lg">
                <TrendingUp className="h-5 w-5 text-accent" />
                Weekly Progress
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <div className="flex justify-between text-sm mb-2">
                  <span>Prelims Preparation</span>
                  <span className="text-muted-foreground">0%</span>
                </div>
                <Progress value={0} className="h-2" />
              </div>
              <div>
                <div className="flex justify-between text-sm mb-2">
                  <span>Mains Preparation</span>
                  <span className="text-muted-foreground">0%</span>
                </div>
                <Progress value={0} className="h-2" />
              </div>
              <div>
                <div className="flex justify-between text-sm mb-2">
                  <span>Current Affairs</span>
                  <span className="text-muted-foreground">0%</span>
                </div>
                <Progress value={0} className="h-2" />
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.4 }}
        >
          <Card className="border-0 shadow-md">
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center gap-2 text-lg">
                <Award className="h-5 w-5 text-accent" />
                Recent Achievements
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col items-center justify-center py-8 text-center">
                <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center mb-3">
                  <Award className="h-8 w-8 text-muted-foreground" />
                </div>
                <p className="text-muted-foreground text-sm">
                  Complete tests and evaluations to earn achievements!
                </p>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}
