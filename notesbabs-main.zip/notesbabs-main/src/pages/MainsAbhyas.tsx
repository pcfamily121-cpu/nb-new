import { motion } from "framer-motion";
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import {
  PenTool,
  Send,
  Loader2,
  Clock,
  BookOpen,
  Lightbulb,
  Target,
  ChevronRight,
  Sparkles,
} from "lucide-react";

const dailyQuestions = [
  {
    id: 1,
    question: "Examine the role of civil society in strengthening democratic governance in India. Discuss with examples.",
    topic: "Governance",
    paper: "GS Paper 2",
    wordLimit: 250,
    marks: 15,
  },
  {
    id: 2,
    question: "Analyze the impact of climate change on agricultural productivity in India. Suggest adaptation strategies for Indian farmers.",
    topic: "Environment",
    paper: "GS Paper 3",
    wordLimit: 250,
    marks: 15,
  },
  {
    id: 3,
    question: "Discuss the ethical challenges faced by public servants in implementing welfare schemes. How can these be addressed?",
    topic: "Ethics",
    paper: "GS Paper 4",
    wordLimit: 150,
    marks: 10,
  },
];

export default function MainsAbhyas() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [selectedQuestion, setSelectedQuestion] = useState(dailyQuestions[0]);
  const [answer, setAnswer] = useState("");
  const [loading, setLoading] = useState(false);
  const [topicAnalysis, setTopicAnalysis] = useState<{
    keyPoints: string[];
    relatedTopics: string[];
    exampleIdeas: string[];
  } | null>(null);

  const handleGetTopicAnalysis = async () => {
    setLoading(true);
    setTopicAnalysis(null);

    try {
      const { data, error } = await supabase.functions.invoke("ai-topic-analysis", {
        body: { question: selectedQuestion.question, topic: selectedQuestion.topic },
      });

      if (error) throw error;

      setTopicAnalysis(data);
      toast({
        title: "Topic Analysis Ready!",
        description: "AI has analyzed the topic for you.",
      });
    } catch (error: any) {
      console.error("Topic analysis error:", error);
      toast({
        title: "Analysis Failed",
        description: error.message || "Something went wrong. Please try again.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleSubmitAnswer = async () => {
    if (!answer.trim()) {
      toast({
        title: "No Answer",
        description: "Please write your answer before submitting.",
        variant: "destructive",
      });
      return;
    }

    toast({
      title: "Answer Submitted!",
      description: "Head to AI Evaluation to get your answer evaluated.",
    });
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <h1 className="text-3xl font-display font-bold flex items-center gap-3">
          <div className="p-2 rounded-xl bg-accent/10">
            <PenTool className="h-7 w-7 text-accent" />
          </div>
          Mains Abhyas
        </h1>
        <p className="text-muted-foreground mt-1">
          Daily mains answer writing practice with AI topic analysis
        </p>
      </motion.div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Questions List */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.1 }}
          className="space-y-4"
        >
          <h2 className="text-lg font-semibold">Today's Questions</h2>
          {dailyQuestions.map((q, index) => (
            <Card
              key={q.id}
              className={`border-0 shadow-md cursor-pointer transition-all duration-300 ${
                selectedQuestion.id === q.id
                  ? "ring-2 ring-accent"
                  : "hover:shadow-lg"
              }`}
              onClick={() => {
                setSelectedQuestion(q);
                setTopicAnalysis(null);
                setAnswer("");
              }}
            >
              <CardContent className="p-4">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <div className="flex gap-2 mb-2">
                      <Badge variant="secondary" className="text-xs">
                        {q.paper}
                      </Badge>
                      <Badge variant="outline" className="text-xs">
                        {q.topic}
                      </Badge>
                    </div>
                    <p className="text-sm line-clamp-2">{q.question}</p>
                    <div className="flex items-center gap-3 mt-2 text-xs text-muted-foreground">
                      <span>{q.wordLimit} words</span>
                      <span>{q.marks} marks</span>
                    </div>
                  </div>
                  <ChevronRight className={`h-5 w-5 transition-colors ${
                    selectedQuestion.id === q.id ? "text-accent" : "text-muted-foreground"
                  }`} />
                </div>
              </CardContent>
            </Card>
          ))}
        </motion.div>

        {/* Answer Writing Area */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="lg:col-span-2 space-y-4"
        >
          {/* Selected Question */}
          <Card className="border-0 shadow-lg">
            <CardHeader>
              <div className="flex items-start justify-between gap-4">
                <div>
                  <div className="flex gap-2 mb-2">
                    <Badge>{selectedQuestion.paper}</Badge>
                    <Badge variant="secondary">{selectedQuestion.topic}</Badge>
                  </div>
                  <CardTitle className="text-lg">{selectedQuestion.question}</CardTitle>
                </div>
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Clock className="h-4 w-4" />
                  {selectedQuestion.wordLimit} words
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* AI Topic Analysis */}
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  onClick={handleGetTopicAnalysis}
                  disabled={loading}
                  className="gap-2"
                >
                  {loading ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <Sparkles className="h-4 w-4" />
                  )}
                  Get AI Topic Analysis
                </Button>
              </div>

              {topicAnalysis && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="bg-muted/50 rounded-xl p-4 space-y-4"
                >
                  <h3 className="font-semibold flex items-center gap-2">
                    <Lightbulb className="h-4 w-4 text-yellow-500" />
                    AI Topic Analysis
                  </h3>
                  
                  <div className="space-y-3">
                    <div>
                      <p className="text-sm font-medium mb-1">Key Points to Cover:</p>
                      <ul className="text-sm text-muted-foreground space-y-1">
                        {topicAnalysis.keyPoints.map((point, i) => (
                          <li key={i} className="flex items-start gap-2">
                            <Target className="h-3 w-3 mt-1 text-accent" />
                            {point}
                          </li>
                        ))}
                      </ul>
                    </div>
                    
                    <div>
                      <p className="text-sm font-medium mb-1">Related Topics:</p>
                      <div className="flex flex-wrap gap-2">
                        {topicAnalysis.relatedTopics.map((topic, i) => (
                          <Badge key={i} variant="outline" className="text-xs">
                            {topic}
                          </Badge>
                        ))}
                      </div>
                    </div>
                    
                    <div>
                      <p className="text-sm font-medium mb-1">Example Ideas:</p>
                      <ul className="text-sm text-muted-foreground space-y-1">
                        {topicAnalysis.exampleIdeas.map((example, i) => (
                          <li key={i} className="flex items-start gap-2">
                            <BookOpen className="h-3 w-3 mt-1 text-emerald-500" />
                            {example}
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </motion.div>
              )}

              {/* Answer Textarea */}
              <div className="space-y-2">
                <Textarea
                  placeholder="Write your answer here..."
                  value={answer}
                  onChange={(e) => setAnswer(e.target.value)}
                  rows={12}
                  className="resize-none"
                />
                <div className="flex items-center justify-between">
                  <p className="text-xs text-muted-foreground">
                    Word count: {answer.split(/\s+/).filter(Boolean).length} / {selectedQuestion.wordLimit}
                  </p>
                  <Button onClick={handleSubmitAnswer} className="gap-2">
                    <Send className="h-4 w-4" />
                    Submit Answer
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}
