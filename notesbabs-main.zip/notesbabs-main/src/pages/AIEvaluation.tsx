import { motion } from "framer-motion";
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import {
  Brain,
  Send,
  Loader2,
  CheckCircle,
  AlertCircle,
  Lightbulb,
  Target,
  FileText,
  Sparkles,
} from "lucide-react";

export default function AIEvaluation() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [question, setQuestion] = useState("");
  const [answer, setAnswer] = useState("");
  const [loading, setLoading] = useState(false);
  const [evaluation, setEvaluation] = useState<{
    score: number;
    feedback: string;
    strengths: string[];
    improvements: string[];
  } | null>(null);

  const handleEvaluate = async () => {
    if (!question.trim() || !answer.trim()) {
      toast({
        title: "Missing Information",
        description: "Please enter both the question and your answer.",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);
    setEvaluation(null);

    try {
      const { data, error } = await supabase.functions.invoke("ai-evaluate", {
        body: { question, answer },
      });

      if (error) throw error;

      setEvaluation(data);
      
      // Save evaluation to database
      if (user) {
        await supabase.from("ai_evaluations").insert({
          user_id: user.id,
          question_text: question,
          user_answer: answer,
          ai_feedback: data.feedback,
          ai_score: data.score,
          max_score: 10,
        });
      }

      toast({
        title: "Evaluation Complete!",
        description: "Your answer has been evaluated by AI.",
      });
    } catch (error: any) {
      console.error("Evaluation error:", error);
      toast({
        title: "Evaluation Failed",
        description: error.message || "Something went wrong. Please try again.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const getScoreColor = (score: number) => {
    if (score >= 8) return "text-emerald-500";
    if (score >= 6) return "text-yellow-500";
    if (score >= 4) return "text-orange-500";
    return "text-red-500";
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <h1 className="text-3xl font-display font-bold flex items-center gap-3">
          <div className="p-2 rounded-xl bg-accent/10">
            <Brain className="h-7 w-7 text-accent" />
          </div>
          AI Answer Evaluation
        </h1>
        <p className="text-muted-foreground mt-1">
          Get your UPSC answers evaluated by AI with detailed feedback
        </p>
      </motion.div>

      {/* Info Cards */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.1 }}
        className="grid sm:grid-cols-3 gap-4"
      >
        <Card className="border-0 shadow-md">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="p-2 rounded-lg bg-purple-100">
              <Sparkles className="h-5 w-5 text-purple-600" />
            </div>
            <div>
              <p className="font-medium text-sm">AI-Powered</p>
              <p className="text-xs text-muted-foreground">Advanced evaluation</p>
            </div>
          </CardContent>
        </Card>
        <Card className="border-0 shadow-md">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="p-2 rounded-lg bg-blue-100">
              <Target className="h-5 w-5 text-blue-600" />
            </div>
            <div>
              <p className="font-medium text-sm">UPSC Pattern</p>
              <p className="text-xs text-muted-foreground">Exam-focused scoring</p>
            </div>
          </CardContent>
        </Card>
        <Card className="border-0 shadow-md">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="p-2 rounded-lg bg-emerald-100">
              <FileText className="h-5 w-5 text-emerald-600" />
            </div>
            <div>
              <p className="font-medium text-sm">Detailed Feedback</p>
              <p className="text-xs text-muted-foreground">Actionable insights</p>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Input Form */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
      >
        <Card className="border-0 shadow-lg">
          <CardHeader>
            <CardTitle>Submit Your Answer</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="question">Question</Label>
              <Input
                id="question"
                placeholder="Enter the UPSC question here..."
                value={question}
                onChange={(e) => setQuestion(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="answer">Your Answer</Label>
              <Textarea
                id="answer"
                placeholder="Write your answer here (150-250 words recommended for GS questions)..."
                value={answer}
                onChange={(e) => setAnswer(e.target.value)}
                rows={8}
                className="resize-none"
              />
              <p className="text-xs text-muted-foreground">
                Word count: {answer.split(/\s+/).filter(Boolean).length}
              </p>
            </div>
            <Button
              onClick={handleEvaluate}
              disabled={loading}
              className="w-full gap-2"
            >
              {loading ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  Evaluating...
                </>
              ) : (
                <>
                  <Send className="h-4 w-4" />
                  Evaluate Answer
                </>
              )}
            </Button>
          </CardContent>
        </Card>
      </motion.div>

      {/* Evaluation Results */}
      {evaluation && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <Card className="border-0 shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CheckCircle className="h-5 w-5 text-emerald-500" />
                Evaluation Results
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Score */}
              <div className="text-center py-6 bg-muted/50 rounded-xl">
                <p className="text-sm text-muted-foreground mb-2">Your Score</p>
                <p className={`text-5xl font-bold ${getScoreColor(evaluation.score)}`}>
                  {evaluation.score}/10
                </p>
                <Progress
                  value={evaluation.score * 10}
                  className="mt-4 h-3 w-48 mx-auto"
                />
              </div>

              {/* Feedback */}
              <div className="space-y-2">
                <h4 className="font-semibold flex items-center gap-2">
                  <Lightbulb className="h-4 w-4 text-yellow-500" />
                  Detailed Feedback
                </h4>
                <p className="text-muted-foreground leading-relaxed">
                  {evaluation.feedback}
                </p>
              </div>

              {/* Strengths & Improvements */}
              <div className="grid sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <h4 className="font-semibold flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-emerald-500" />
                    Strengths
                  </h4>
                  <ul className="space-y-1">
                    {evaluation.strengths.map((strength, index) => (
                      <li key={index} className="flex items-start gap-2 text-sm">
                        <Badge variant="secondary" className="mt-0.5 h-5 w-5 p-0 flex items-center justify-center rounded-full text-xs">
                          {index + 1}
                        </Badge>
                        {strength}
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="space-y-2">
                  <h4 className="font-semibold flex items-center gap-2">
                    <AlertCircle className="h-4 w-4 text-orange-500" />
                    Areas for Improvement
                  </h4>
                  <ul className="space-y-1">
                    {evaluation.improvements.map((improvement, index) => (
                      <li key={index} className="flex items-start gap-2 text-sm">
                        <Badge variant="outline" className="mt-0.5 h-5 w-5 p-0 flex items-center justify-center rounded-full text-xs">
                          {index + 1}
                        </Badge>
                        {improvement}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      )}
    </div>
  );
}
