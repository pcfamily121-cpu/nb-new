import { useEffect, useRef } from "react";
import { Capacitor } from "@capacitor/core";
import { PushNotifications } from "@capacitor/push-notifications";
import { useToast } from "@/hooks/use-toast";

export function usePushNotifications() {
  const { toast } = useToast();
  const initialized = useRef(false);

  useEffect(() => {
    if (initialized.current) return;
    if (!Capacitor.isNativePlatform()) return;
    initialized.current = true;

    const register = async () => {
      const permission = await PushNotifications.requestPermissions();
      if (permission.receive !== "granted") {
        console.log("Push notification permission denied");
        return;
      }

      await PushNotifications.register();

      PushNotifications.addListener("registration", (token) => {
        console.log("Push registration token:", token.value);
        // TODO: Send token to your backend to store for this user
      });

      PushNotifications.addListener("registrationError", (error) => {
        console.error("Push registration error:", error);
      });

      PushNotifications.addListener("pushNotificationReceived", (notification) => {
        toast({
          title: notification.title || "Notification",
          description: notification.body || "",
        });
      });

      PushNotifications.addListener("pushNotificationActionPerformed", (action) => {
        console.log("Push action performed:", action);
      });
    };

    register();

    return () => {
      PushNotifications.removeAllListeners();
    };
  }, [toast]);
}
